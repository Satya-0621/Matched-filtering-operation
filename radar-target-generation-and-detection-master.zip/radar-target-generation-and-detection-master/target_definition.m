% target_definition.m
% User Defined Range and Velocity of target
range = 110;  % Initial position
vel = -20;  % Velocity (constant)