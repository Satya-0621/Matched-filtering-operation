clear all
clc;